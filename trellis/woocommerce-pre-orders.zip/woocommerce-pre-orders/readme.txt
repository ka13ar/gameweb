=== WooCommerce Pre-Orders ===
Author: woothemes
Requires at least: 3.5
Tested up to: 3.5.1
Stable tag: 1.0.4

== Description ==

Sell pre-orders for products in your WooCommerce store

See http://docs.woothemes.com/document/pre-orders/ for full documentation.
